﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Book_Shop
{
    public partial class Anbar_Frm : Form
    {
        ConnectDb dbs = new ConnectDb();
        public string id, sh_book;

        public Anbar_Frm()
        {
            InitializeComponent();
        }

        public void refresh()
        {
            dbs.connect();
            dataGridView1.DataSource = dbs.select("Select Books.shbook as '" + "شناسه کتاب" + "',Books.name_book as '" + "نام کتاب" + "',Books.subject as '" + "موضوع کتاب" + "',Books.aouther as '" + "نویسنده کتاب" + "',Books.price as '" + "قیمت کتاب" + "',Anbar.count as '" + "تعداد موجودی انبار" + "' From Books Inner Join Anbar on Books.shbook=Anbar.shbook");
            dbs.disconnect();

            txt_name_book.Text = null;
            txt_count.Text = "0";
        }

        private void Anbar_Frm_Load(object sender, EventArgs e)
        {
            refresh();

            lbl_count.Text = dataGridView1.Rows.Count.ToString();
        }

        private void btn_new_Click(object sender, EventArgs e)
        {
            btn_save.Enabled = true;
            btn_new.Enabled = false;

            refresh();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
            btn_save.Enabled = false;
            btn_new.Enabled = true;
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            dbs.connect();
            dbs.docommand("Insert Into Anbar(shbook,count) Values('" + sh_book + "','" + txt_count.Text + "')");
            dbs.disconnect();

            refresh();
            MessageBox.Show("عملیات ثبت اطلاعات کتاب با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
            btn_save.Enabled = false;
            btn_new.Enabled = true;

            lbl_count.Text = dataGridView1.Rows.Count.ToString();
        }

        private void btn_edit_Click(object sender, EventArgs e)
        {
            dbs.connect();
            dbs.docommand("Update Anbar Set shbook='" + sh_book + "',count='" + txt_count.Text + "' Where shbook='" + txt_shbook.Text + "'");
            dbs.disconnect();

            refresh();
            MessageBox.Show("عملیات ویرایش اطلاعات کتاب با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("آیا مطمئن به حذف کتاب مورد نظر می باشد", "هشدار", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes) ;
            {
                dbs.connect();
                dbs.docommand("Delete From Anbar Where shbook='" + txt_shbook.Text + "'");
                dbs.disconnect();

                refresh();
            }

            lbl_count.Text = dataGridView1.Rows.Count.ToString();
        }

        private void btn_refresh_Click(object sender, EventArgs e)
        {
            refresh();

            btn_save.Enabled = false;
            btn_new.Enabled = true;

            lbl_count.Text = dataGridView1.Rows.Count.ToString();
        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            txt_search.Text = txt_search.Text.Replace("ی", "ي");
            txt_search.SelectionStart = txt_search.Text.Length;

            dbs.connect();
            dataGridView1.DataSource = dbs.select("Select Books.shbook as '" + "شناسه کتاب" + "',Books.name_book as '" + "نام کتاب" + "',Books.subject as '" + "موضوع کتاب" + "',Books.aouther as '" + "نویسنده کتاب" + "',Books.price as '" + "قیمت کتاب" + "',Anbar.count as '" + "تعداد موجودی انبار" + "' From Books Inner Join Anbar on Books.shbook=Anbar.shbook Where Books.shbook='" + txt_search.Text + "' or Books.name_book='" + txt_search.Text + "'");
            dbs.disconnect();

            lbl_count.Text = dataGridView1.Rows.Count.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Search_Book_Frm sbf = new Search_Book_Frm();
            sbf.ShowDialog();
            txt_shbook.Text=sbf.idbook;
            sh_book = sbf.idbook;
            txt_name_book.Text = sbf.namebook;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            //pass
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            sh_book = dataGridView1[0, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_shbook.Text = dataGridView1[0, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_name_book.Text = dataGridView1[1, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_count.Text = dataGridView1[5, dataGridView1.CurrentRow.Index].Value.ToString();
        }
    }
}
