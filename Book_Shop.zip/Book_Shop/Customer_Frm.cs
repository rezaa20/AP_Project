﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Globalization;

namespace Book_Shop
{
    public partial class Customer_Frm : Form
    {
        ConnectDb dbs = new ConnectDb();
        public string id, sh_book, date_sabt;

        public Customer_Frm()
        {
            InitializeComponent();
        }


        public void refresh()
        {

            dbs.connect();
            dataGridView1.DataSource = dbs.select("Select * From Customer");
            dbs.disconnect();

            txt_address.Text = null;
            txt_fname.Text = null;
            txt_lname.Text = null;
            txt_mobile.Text = null;
            txt_shcustomer.Text = null;
            txt_tel.Text = null;
            chk_shenas.Checked = false;
        }

        private void btn_new_Click(object sender, EventArgs e)
        {
            txt_shcustomer.Focus();
            btn_save.Enabled = true;
            btn_new.Enabled = false;

            refresh();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            dbs.connect();
            dbs.docommand("Insert Into Customer(sh_customer,fname,lname,tel,mobile,adress,date_sabt) Values('" + txt_shcustomer.Text + "','" + txt_fname.Text + "','" + txt_lname.Text + "','" + txt_tel.Text + "','" + txt_mobile.Text + "','" + txt_address.Text + "','" + date_sabt + "')");
            dbs.disconnect();

            refresh();
            MessageBox.Show("عملیات ثبت اطلاعات مشتری با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
            btn_save.Enabled = false;
            btn_new.Enabled = true;

            lbl_count.Text = dataGridView1.Rows.Count.ToString();
        }

        private void btn_edit_Click(object sender, EventArgs e)
        {
            dbs.connect();
            dbs.docommand("Update Customer Set sh_customer='" + txt_shcustomer.Text + "',fname='" + txt_fname.Text + "',lname='" + txt_lname.Text + "',tel='" + txt_tel.Text + "',mobile='" + txt_mobile.Text + "',adress='" + txt_address.Text + "' Where ID='" + id + "'");
            dbs.disconnect();

            refresh();
            MessageBox.Show("عملیات ویرایش اطلاعات مشتری با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("آیا مطمئن به حذف مشتری مورد نظر می باشد", "هشدار", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes) ;
            {
                dbs.connect();
                dbs.docommand("Delete From Customer Where ID='" + id + "'");
                dbs.disconnect();

                refresh();
            }

            lbl_count.Text = dataGridView1.Rows.Count.ToString();
        }

        private void btn_refresh_Click(object sender, EventArgs e)
        {
            refresh();

            btn_save.Enabled = false;
            btn_new.Enabled = true;

            lbl_count.Text = dataGridView1.Rows.Count.ToString();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
            btn_save.Enabled = false;
            btn_new.Enabled = true;
        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            txt_search.Text = txt_search.Text.Replace("ی", "ي");
            txt_search.SelectionStart = txt_search.Text.Length;

            dbs.connect();
            dataGridView1.DataSource = dbs.select("Select * From Customer Where sh_customer='" + txt_search.Text + "' or lname Like N'%" + txt_search.Text + "%' or date_sabt Like N'%" + txt_search.Text + "%'");
            dbs.disconnect();

            lbl_count.Text = dataGridView1.Rows.Count.ToString();
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            id = dataGridView1[0, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_shcustomer.Text = dataGridView1[1, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_fname.Text = dataGridView1[2, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_lname.Text = dataGridView1[3, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_tel.Text = dataGridView1[4, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_mobile.Text = dataGridView1[5, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_address.Text = dataGridView1[6, dataGridView1.CurrentRow.Index].Value.ToString();

        }

        private void Customer_Frm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'customer_Dataset.Customer' table. You can move, or remove it, as needed.
            //this.customerTableAdapter.Fill(this.customer_Dataset.Customer);

            PersianCalendar shdate = new PersianCalendar();
            date_sabt = shdate.GetYear(DateTime.Now).ToString() + "/" + shdate.GetMonth(DateTime.Now).ToString().PadLeft(2, '0') + "/" + shdate.GetDayOfMonth(DateTime.Now).ToString().PadLeft(2, '0');
        }

        private void chk_shenas_CheckedChanged(object sender, EventArgs e)
        {
            int count;
            DataTable dt = new DataTable();
            if (chk_shenas.Checked == true)
            {
                dbs.connect();
                dt = dbs.select("Select * From Customer");
                count = dt.Rows.Count - 1;
                if (count == -1)
                    MessageBox.Show("کاربر محترم امکان دریافت اتوماتیک شناسه مشتری وجود ندارد", "هشدار", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                else
                    txt_shcustomer.Text = (Convert.ToInt32(dt.Rows[count][1]) + 1).ToString();
            }
            else
                txt_shcustomer.Text = null;
            dbs.disconnect();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btn_kharid_Click(object sender, EventArgs e)
        {
            List_Kharid_Frm lkf = new List_Kharid_Frm();
            lkf.sh_customer = txt_shcustomer.Text;
            lkf.ShowDialog();
        }

        private void btn_factor_Click(object sender, EventArgs e)
        {
            Factor_Frm ff = new Factor_Frm();
            ff.sh_custom = txt_shcustomer.Text;
            ff.ShowDialog();
            
        }

    }
}
