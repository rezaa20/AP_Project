﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Globalization;

namespace Book_Shop
{
    public partial class ListForosh_Frm : Form
    {
        ConnectDb dbs = new ConnectDb();
        public string id, id_book, sh_customer, date_sabt;

        public ListForosh_Frm()
        {
            InitializeComponent();
        }

        public void refresh()
        {
            dbs.connect();
            dataGridView1.DataSource = dbs.select("Select Forosh.sh_customer as '" + "شناسه مشتری" + "',Forosh.count as '" + "تعداد کتاب" + "',Forosh.price_col as '" + "قیمت کل" + "',Books.shbook as '" + "شناسه کتاب" + "',Books.name_book as '" + "نام کتاب" + "',Books.subject as '" + "موضوع کتاب" + "',Books.aouther as '" + "نویسنده کتاب" + "',Books.price as '" + "قیمت کتاب" + "',Customer.date_sabt as '" + "تاریخ فروش" + "' From Forosh Inner Join Books on Forosh.sh_book=Books.shbook Inner Join Customer on Customer.sh_customer=Forosh.sh_customer");
            dbs.disconnect();
        }

        public void sum_price()
        {
            int result = 0;
            foreach (DataGridViewRow row in this.dataGridView1.Rows)
            {
                result += Convert.ToInt32(row.Cells[2].Value);
            }
            lbl_price.Text = result.ToString();
        }
        //...جمع ستون

        private void ListForosh_Frm_Load(object sender, EventArgs e)
        {
            PersianCalendar shdate = new PersianCalendar();
            date_sabt = shdate.GetYear(DateTime.Now).ToString() + "/" + shdate.GetMonth(DateTime.Now).ToString().PadLeft(2, '0') + "/" + shdate.GetDayOfMonth(DateTime.Now).ToString().PadLeft(2, '0');

            dbs.connect();
            dataGridView1.DataSource = dbs.select("Select Forosh.sh_customer as '" + "شناسه مشتری" + "',Forosh.count as '" + "تعداد کتاب" + "',Forosh.price_col as '" + "قیمت کل" + "',Books.shbook as '" + "شناسه کتاب" + "',Books.name_book as '" + "نام کتاب" + "',Books.subject as '" + "موضوع کتاب" + "',Books.aouther as '" + "نویسنده کتاب" + "',Books.price as '" + "قیمت کتاب" + "',Customer.date_sabt as '" + "تاریخ فروش" + "' From Forosh Inner Join Books on Forosh.sh_book=Books.shbook Inner Join Customer on Customer.sh_customer=Forosh.sh_customer Where Customer.date_sabt='" + date_sabt + "'");
            dbs.disconnect();

            lbl_count.Text = dataGridView1.Rows.Count.ToString();

            sum_price();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            refresh();
            sum_price();
            txt_date.Text = null;
            txt_name_book.Text = null;
            txt_shenas.Text = null;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dbs.connect();
            //dataGridView1.DataSource = dbs.select("Select Forosh.sh_customer as '" + "شناسه مشتری" + "',Books.shbook as '" + "شناسه کتاب" + "',Books.name_book as '" + "نام کتاب" + "',Books.subject as '" + "موضوع کتاب" + "',Books.aouther as '" + "نویسنده کتاب" + "',Books.price as '" + "قیمت کتاب" + "',Customer.date_sabt as '" + "تاریخ فروش" + "' From Forosh Inner Join Books on Forosh.sh_book=Books.shbook Inner Join Customer on Customer.sh_customer=Forosh.sh_customer Where Customer.date_sabt='" + txt_date.Text + "' or Forosh.sh_book='" + txt_shenas.Text + "' or Books.name_book='" + txt_name_book.Text + "'");
            dataGridView1.DataSource = dbs.select("Select Forosh.sh_customer as '" + "شناسه مشتری" + "',Forosh.count as '" + "تعداد کتاب" + "',Forosh.price_col as '" + "قیمت کل" + "',Books.shbook as '" + "شناسه کتاب" + "',Books.name_book as '" + "نام کتاب" + "',Books.subject as '" + "موضوع کتاب" + "',Books.aouther as '" + "نویسنده کتاب" + "',Books.price as '" + "قیمت کتاب" + "',Customer.date_sabt as '" + "تاریخ فروش" + "' From Forosh Inner Join Books on Forosh.sh_book=Books.shbook Inner Join Customer on Customer.sh_customer=Forosh.sh_customer Where Customer.date_sabt='" + txt_date.Text + "' or Forosh.sh_book='" + txt_shenas.Text + "' or Books.name_book='" + txt_name_book.Text + "'");
            dbs.disconnect();

            sum_price();
        }
    }
}
