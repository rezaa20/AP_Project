﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Book_Shop
{
    public partial class Changeuser_Frm : Form
    {
        public Changeuser_Frm()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int id;
            ConnectDb dbs = new ConnectDb();
            DataTable dt = new DataTable();

            dbs.connect();
            dt = dbs.select("Select * From Login Where username='" + txt_username.Text + "' and password='" + txt_password.Text + "'");
            if (txt_new_password.Text != txt_repassword.Text)
                MessageBox.Show("كاربر گرامي رمز عبور با تكرار رمز عبور برابر نيست", "اخطار", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
                if (dt.Rows.Count > 0)
                {
                    id = Convert.ToInt32(dt.Rows[0][0].ToString());
                    dbs.docommand("Update Login Set password='" + txt_new_password.Text + "' Where ID='" + id + "'");
                    MessageBox.Show("كاربر محترم عمليات تغيير اطلاعات با موفقيت انجام شد", "پيغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                    MessageBox.Show("كاربر محترم چنين نام كاربري وجود ندارد", "اخطار", MessageBoxButtons.OK, MessageBoxIcon.Error);

            txt_username.Text = null;
            txt_password.Text = null;
            txt_repassword.Text = null;
            txt_new_password.Text = null;
            dbs.disconnect();
        }

        private void Changeuser_Frm_Load(object sender, EventArgs e)
        {

        }
    }
}
