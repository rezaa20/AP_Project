﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Book_Shop
{
    public partial class Search_Book_Frm : Form
    {
        public string idbook, namebook;
        public int price;
        public Search_Book_Frm()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Search_Book_Frm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'book_Dataset.Books' table. You can move, or remove it, as needed.
            //this.booksTableAdapter.Fill(this.book_Dataset.Books);
        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            txt_search.Text = txt_search.Text.Replace("ی", "ي");
            //..جایگزین کردن کاراکتر ي به جای کاراکتر ی 
            txt_search.SelectionStart = txt_search.Text.Length;
            //..رفتن به آخر متن در تکست باکس

            ConnectDb dbs = new ConnectDb();
            dbs.connect();
            dataGridView1.DataSource = dbs.select("Select * From Books Where shbook='" + txt_search.Text + "' or name_book Like N'%" + txt_search.Text + "%' or subject Like N'%" + txt_search.Text + "%' or aouther Like N'%" + txt_search.Text + "%'");
            dbs.disconnect();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            idbook = dataGridView1[1, dataGridView1.CurrentRow.Index].Value.ToString();
            namebook = dataGridView1[2, dataGridView1.CurrentRow.Index].Value.ToString();
            price = Convert.ToInt32(dataGridView1[5, dataGridView1.CurrentRow.Index].Value.ToString());

            this.Close();
        }
    }
}
