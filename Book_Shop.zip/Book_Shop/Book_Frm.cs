﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Book_Shop
{
    public partial class Book_Frm : Form
    {
        ConnectDb dbs = new ConnectDb();
        string id;

        public Book_Frm()
        {
            InitializeComponent();
        }



        private void Book_Frm_Load(object sender, EventArgs e)
        {


            lbl_count.Text = dataGridView1.Rows.Count.ToString();
        }


        public void refresh()
        {

            dbs.connect();
            dataGridView1.DataSource = dbs.select("Select * From Books");
            dbs.disconnect();

            txt_name_book.Text = null;
            txt_price.Text = "0";
            txt_publisher.Text = null;
            com_subject.Text = null;
            txt_sal_publish.Text = null;
            txt_shabk.Text = null;
            txt_shbook.Text = null;
            txt_tiraj.Text = null;
            chk_shenas.Checked = false;
            txt_author.Text = null;
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
            btn_save.Enabled = false;
            btn_new.Enabled = true;
        }

        private void btn_new_Click(object sender, EventArgs e)
        {
            btn_save.Enabled = true;
            btn_new.Enabled = false;

            refresh();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            dbs.connect();
            dbs.docommand("Insert Into Books(shbook,name_book,subject,aouther,publisher,sal_publish,tiraj,price,shabk) Values('" + txt_shbook.Text + "','" + txt_name_book.Text + "','" + com_subject.Text + "','" + txt_author.Text + "','" + txt_publisher.Text + "','" + txt_sal_publish.Text + "','" + txt_tiraj.Text + "','" + txt_price.Text + "','" + txt_shabk.Text + "')");
            dbs.disconnect();

            refresh();
            MessageBox.Show("عملیات ثبت اطلاعات کتاب با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
            btn_save.Enabled = false;
            btn_new.Enabled = true;

            lbl_count.Text = dataGridView1.Rows.Count.ToString();

        }

        private void btn_edit_Click(object sender, EventArgs e)
        {
            dbs.connect();
            dbs.docommand("Update Books Set shbook='" + txt_shbook.Text + "',name_book='" + txt_name_book.Text + "',subject='" + com_subject.Text + "',aouther='" + txt_author.Text + "',publisher='" + txt_publisher.Text + "',sal_publish='" + txt_sal_publish.Text + "',tiraj='" + txt_tiraj.Text + "',price='" + txt_price.Text + "',shabk='" + txt_shabk.Text + "' Where ID='" + id + "'");
            dbs.disconnect();

            refresh();
            MessageBox.Show("عملیات ویرایش اطلاعات کتاب با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("آیا مطمئن به حذف کتاب مورد نظر می باشد", "هشدار", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes) ;
            {
                dbs.connect();
                dbs.docommand("Delete From Books Where ID='" + id + "'");
                dbs.disconnect();

                refresh();
            }

            lbl_count.Text = dataGridView1.Rows.Count.ToString();
        }

        private void btn_refresh_Click(object sender, EventArgs e)
        {
            refresh();

            btn_save.Enabled = false;
            btn_new.Enabled = true;

            lbl_count.Text = dataGridView1.Rows.Count.ToString();

        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            id = dataGridView1[0, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_shbook.Text = dataGridView1[1, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_name_book.Text = dataGridView1[2, dataGridView1.CurrentRow.Index].Value.ToString();
            com_subject.Text = dataGridView1[3, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_author.Text = dataGridView1[4, dataGridView1.CurrentRow.Index].Value.ToString();           
            txt_publisher.Text = dataGridView1[5, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_sal_publish.Text = dataGridView1[6, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_tiraj.Text = dataGridView1[7, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_price.Text = dataGridView1[8, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_shabk.Text = dataGridView1[9, dataGridView1.CurrentRow.Index].Value.ToString();

        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            txt_search.Text = txt_search.Text.Replace("ی", "ي");
            txt_search.SelectionStart = txt_search.Text.Length;

            dbs.connect();
            dataGridView1.DataSource = dbs.select("Select * From Books Where shbook='" + txt_search.Text + "' or name_book Like N'%" + txt_search.Text + "%' or subject Like N'%" + txt_search.Text + "%' or aouther Like N'%" + txt_search.Text + "%'");
            dbs.disconnect();

            lbl_count.Text = dataGridView1.Rows.Count.ToString();

        }

        private void chk_shenas_CheckedChanged(object sender, EventArgs e)
        {
            int count;
            DataTable dt = new DataTable();
            if (chk_shenas.Checked == true)
            {
                dbs.connect();
                dt = dbs.select("Select * From Books");
                count = dt.Rows.Count - 1;
                if (count == -1)
                    MessageBox.Show("کاربر محترم امکان دریافت اتوماتیک شناسه کتاب وجود ندارد", "هشدار", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                else
                    txt_shbook.Text = (Convert.ToInt32(dt.Rows[count][1]) + 1).ToString();
            }
            else
                txt_shbook.Text = null;
            dbs.disconnect();
        }
    }
}
