﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Book_Shop
{
    public partial class Newuser_Frm : Form
    {
        ConnectDb dbs = new ConnectDb();
        string id, user_type;

        public Newuser_Frm()
        {
            InitializeComponent();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
            btn_save.Enabled = false;
            btn_new.Enabled = true;
        }

        public void usertype()
        {
            if (com_usertype.SelectedIndex == 0)
                user_type = "1";
            else
                if (com_usertype.SelectedIndex == 1)
                    user_type = "0";
        }

        public void refresh()
        {

            dbs.connect();
            dataGridView1.DataSource = dbs.select("Select * From Login");
            dbs.disconnect();

            txt_fname.Text = null;
            txt_lname.Text = null;
            txt_password.Text = null;
            txt_repassword.Text = null;
            txt_username.Text = null;
            com_usertype.Text = null;
        }

        private void btn_new_Click(object sender, EventArgs e)
        {
            btn_save.Enabled = true;
            btn_new.Enabled = false;

            refresh();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            usertype();
            dbs.connect();
            dbs.docommand("Insert Into Login(fname,lname,username,password,usertype) Values(N'" + txt_fname.Text + "',N'" + txt_lname.Text + "',N'" + txt_username.Text + "',N'" + txt_password.Text + "',N'" + user_type + "')");
            dbs.disconnect();

            refresh();
            MessageBox.Show("عملیات ثبت اطلاعات کاربر با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
            btn_save.Enabled = false;
            btn_new.Enabled = true;
        }

        private void btn_edit_Click(object sender, EventArgs e)
        {
            usertype();
            dbs.connect();
            dbs.docommand("Update Login Set fname=N'" + txt_fname.Text + "',lname=N'" + txt_lname.Text + "',username=N'" + txt_username.Text + "',password=N'" + txt_password.Text + "',usertype=N'" + user_type + "' Where ID=N'" + id + "'");
            dbs.disconnect();

            refresh();
            MessageBox.Show("عملیات ویرایش اطلاعات کاربر با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("آیا مطمئن به حذف کاربر مورد نظر می باشد", "هشدار", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes) ;
            {
                dbs.connect();
                dbs.docommand("Delete From Login Where ID='" + id + "'");
                dbs.disconnect();

                refresh();
            }
        }

        private void btn_refresh_Click(object sender, EventArgs e)
        {
            refresh();

            btn_save.Enabled = false;
            btn_new.Enabled = true;
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            id = dataGridView1[0, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_fname.Text = dataGridView1[1, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_lname.Text = dataGridView1[2, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_username.Text = dataGridView1[3, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_password.Text = dataGridView1[4, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_repassword.Text = dataGridView1[4, dataGridView1.CurrentRow.Index].Value.ToString();
            user_type = dataGridView1[5, dataGridView1.CurrentRow.Index].Value.ToString();

            if (user_type == "1")
                com_usertype.Text = "مدیر";
            else
                if (user_type == "0")
                    com_usertype.Text = "فروشنده";
        }

        private void com_usertype_SelectedIndexChanged(object sender, EventArgs e)
        {
            usertype();
        }

        private void Newuser_Frm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'login_Dataset.Login' table. You can move, or remove it, as needed.
            //this.loginTableAdapter.Fill(this.login_Dataset.Login);


        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            ConnectDb dbs = new ConnectDb();
            dbs.connect();
            dataGridView1.DataSource = dbs.select("Select * From Login Where lname Like N'%" + txt_search.Text + "%' or username Like N'%" + txt_search.Text + "%'");
            dbs.disconnect();
        }
    }
}
