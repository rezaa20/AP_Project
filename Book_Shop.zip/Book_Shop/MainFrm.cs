﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Book_Shop
{
    public partial class MainFrm : Form
    {
        public MainFrm()
        {
            InitializeComponent();
        }

        private void ManiFrm_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;

            persianDate pdate = new persianDate(DateTime.Now);
            lbl_date.Text = pdate.CompletePrsDate() + pdate.taghvim();
        }

        private void btn_customer_MouseMove(object sender, MouseEventArgs e)
        {
            btn_customer.BackColor = Color.Orange;
        }

        private void btn_seller_MouseMove(object sender, MouseEventArgs e)
        {
            btn_seller.BackColor = Color.Orange;
        }

        private void btn_books_MouseMove(object sender, MouseEventArgs e)
        {
            btn_books.BackColor = Color.Orange;
        }

        private void btn_anbar_MouseMove(object sender, MouseEventArgs e)
        {
            btn_anbar.BackColor = Color.Orange;
        }

        private void btn_sale_MouseMove(object sender, MouseEventArgs e)
        {
            btn_sale.BackColor = Color.Orange;
        }

        private void btn_newuser_MouseMove(object sender, MouseEventArgs e)
        {
            btn_newuser.BackColor = Color.Orange;
        }

        private void btn_changeuser_MouseMove(object sender, MouseEventArgs e)
        {
            btn_changeuser.BackColor = Color.Orange;
        }

        private void btn_backup_MouseMove(object sender, MouseEventArgs e)
        {
            btn_backup.BackColor = Color.Orange;
        }

        private void btn_lock_MouseMove(object sender, MouseEventArgs e)
        {
            btn_lock.BackColor = Color.Orange;
        }

        private void btn_exit_MouseMove(object sender, MouseEventArgs e)
        {
            btn_exit.BackColor = Color.Orange;
        }

        private void btn_customer_MouseLeave(object sender, EventArgs e)
        {
            btn_customer.BackColor = Color.DarkSlateGray;
        }

        private void btn_seller_MouseLeave(object sender, EventArgs e)
        {
            btn_seller.BackColor = Color.DarkSlateGray;
        }

        private void btn_books_MouseLeave(object sender, EventArgs e)
        {
            btn_books.BackColor = Color.DarkSlateGray;
        }

        private void btn_anbar_MouseLeave(object sender, EventArgs e)
        {
            btn_anbar.BackColor = Color.DarkSlateGray;
        }

        private void btn_sale_MouseLeave(object sender, EventArgs e)
        {
            btn_sale.BackColor = Color.DarkSlateGray;
        }

        private void btn_newuser_MouseLeave(object sender, EventArgs e)
        {
            btn_newuser.BackColor = Color.DarkSlateGray;
        }

        private void btn_changeuser_MouseLeave(object sender, EventArgs e)
        {
            btn_changeuser.BackColor = Color.DarkSlateGray;
        }

        private void btn_backup_MouseLeave(object sender, EventArgs e)
        {
            btn_backup.BackColor = Color.DarkSlateGray;
        }

        private void btn_lock_MouseLeave(object sender, EventArgs e)
        {
            btn_lock.BackColor = Color.DarkSlateGray;
        }

        private void btn_exit_MouseLeave(object sender, EventArgs e)
        {
            btn_exit.BackColor = Color.DarkSlateGray;
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_lock_Click(object sender, EventArgs e)
        {
            Login_Frm log = new Login_Frm();
            this.Hide();
            log.Show();
        }

        private void btn_newuser_Click(object sender, EventArgs e)
        {
            Newuser_Frm nuf = new Newuser_Frm();
            nuf.MdiParent = this;
            nuf.Show();
        }

        private void btn_backup_Click(object sender, EventArgs e)
        {
            Backup_Frm bf = new Backup_Frm();
            bf.MdiParent = this;
            bf.Show();
        }

        private void btn_changeuser_Click(object sender, EventArgs e)
        {
            Changeuser_Frm cf = new Changeuser_Frm();
            cf.MdiParent = this;
            cf.Show();
        }

        private void btn_seller_Click(object sender, EventArgs e)
        {
            Saler_Frm sf = new Saler_Frm();
            sf.MdiParent = this;
            sf.Show();
        }

        private void btn_books_Click(object sender, EventArgs e)
        {
            Book_Frm bf = new Book_Frm();
            bf.MdiParent = this;
            bf.Show();
        }

        private void btn_anbar_Click(object sender, EventArgs e)
        {
            Anbar_Frm af = new Anbar_Frm();
            af.MdiParent = this;
            af.Show();
        }

        private void btn_customer_Click(object sender, EventArgs e)
        {
            Customer_Frm cf = new Customer_Frm();
            cf.MdiParent = this;
            cf.Show();
        }

        private void btn_sale_Click(object sender, EventArgs e)
        {
            ListForosh_Frm lff = new ListForosh_Frm();
            lff.MdiParent = this;
            lff.Show();
        }
    }
}
