﻿namespace Book_Shop
{
    partial class Saler_Frm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Saler_Frm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_date_estekhdam = new System.Windows.Forms.MaskedTextBox();
            this.txt_date_tavalod = new System.Windows.Forms.MaskedTextBox();
            this.txt_semat = new System.Windows.Forms.TextBox();
            this.com_estekhdam = new System.Windows.Forms.ComboBox();
            this.com_madarak = new System.Windows.Forms.ComboBox();
            this.com_sarbazi = new System.Windows.Forms.ComboBox();
            this.com_sex = new System.Windows.Forms.ComboBox();
            this.com_mahal_tavalod = new System.Windows.Forms.ComboBox();
            this.txt_address = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txt_codeposti = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txt_mobile = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txt_tel = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.txt_reshte = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_shmeli = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_shshenas = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_pname = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_lname = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_fname = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_shpersonel = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.btn_new = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btn_save = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.btn_edit = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.btn_delete = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.btn_refresh = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.btn_exit = new System.Windows.Forms.ToolStripButton();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shpersonelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mahaltavalodDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datetavalodDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shshenasDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shmeliDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sexDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sarbaziDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.madrakDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.reshteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sematDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateestekhdamDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.typeestekhdamDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mobileDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.codepostiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.saler_Dataset = new Book_Shop.DataSet.Saler_Dataset();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.salerTableAdapter = new Book_Shop.DataSet.Saler_DatasetTableAdapters.SalerTableAdapter();
            this.panel1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.saler_Dataset)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(995, 45);
            this.panel1.TabIndex = 2;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label1.ForeColor = System.Drawing.Color.Yellow;
            this.label1.Location = new System.Drawing.Point(437, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "فرم اطلاعات فروشنده";
            // 
            // txt_date_estekhdam
            // 
            this.txt_date_estekhdam.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txt_date_estekhdam.Location = new System.Drawing.Point(219, 130);
            this.txt_date_estekhdam.Mask = "####/##/##";
            this.txt_date_estekhdam.Name = "txt_date_estekhdam";
            this.txt_date_estekhdam.Size = new System.Drawing.Size(210, 21);
            this.txt_date_estekhdam.TabIndex = 109;
            // 
            // txt_date_tavalod
            // 
            this.txt_date_tavalod.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txt_date_tavalod.Location = new System.Drawing.Point(680, 180);
            this.txt_date_tavalod.Mask = "####/##/##";
            this.txt_date_tavalod.Name = "txt_date_tavalod";
            this.txt_date_tavalod.Size = new System.Drawing.Size(210, 21);
            this.txt_date_tavalod.TabIndex = 101;
            // 
            // txt_semat
            // 
            this.txt_semat.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txt_semat.Location = new System.Drawing.Point(219, 105);
            this.txt_semat.Name = "txt_semat";
            this.txt_semat.Size = new System.Drawing.Size(210, 21);
            this.txt_semat.TabIndex = 108;
            this.txt_semat.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // com_estekhdam
            // 
            this.com_estekhdam.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.com_estekhdam.FormattingEnabled = true;
            this.com_estekhdam.Items.AddRange(new object[] {
            "پیمانی",
            "رسمی",
            "رسمی آزمایشی",
            "قراردادی",
            "روزمزد",
            "خرید خدمت",
            "مامور",
            "ساعتی",
            "رسمی فصلی",
            "کارمزدی",
            "سایر"});
            this.com_estekhdam.Location = new System.Drawing.Point(219, 155);
            this.com_estekhdam.Name = "com_estekhdam";
            this.com_estekhdam.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.com_estekhdam.Size = new System.Drawing.Size(210, 21);
            this.com_estekhdam.TabIndex = 110;
            // 
            // com_madarak
            // 
            this.com_madarak.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.com_madarak.FormattingEnabled = true;
            this.com_madarak.Items.AddRange(new object[] {
            "بی سواد و کم سواد",
            "زیر دیپلم",
            "دیپلم",
            "کاردانی",
            "کارشناسی",
            "کارشناسی ارشد",
            "دکتری",
            "فوق دکتری",
            "سایر"});
            this.com_madarak.Location = new System.Drawing.Point(219, 55);
            this.com_madarak.Name = "com_madarak";
            this.com_madarak.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.com_madarak.Size = new System.Drawing.Size(210, 21);
            this.com_madarak.TabIndex = 106;
            // 
            // com_sarbazi
            // 
            this.com_sarbazi.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.com_sarbazi.FormattingEnabled = true;
            this.com_sarbazi.Items.AddRange(new object[] {
            "خمت نرفته",
            "پایان خدمت",
            "مشمول",
            "معافیت کفالت",
            "معافیت پزشکی",
            "معافیت تحصیلی",
            "معافیت موارد خاص",
            "درحال خدمت",
            "سایر"});
            this.com_sarbazi.Location = new System.Drawing.Point(680, 280);
            this.com_sarbazi.Name = "com_sarbazi";
            this.com_sarbazi.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.com_sarbazi.Size = new System.Drawing.Size(210, 21);
            this.com_sarbazi.TabIndex = 105;
            // 
            // com_sex
            // 
            this.com_sex.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.com_sex.FormattingEnabled = true;
            this.com_sex.Items.AddRange(new object[] {
            "مرد",
            "زن"});
            this.com_sex.Location = new System.Drawing.Point(680, 255);
            this.com_sex.Name = "com_sex";
            this.com_sex.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.com_sex.Size = new System.Drawing.Size(210, 21);
            this.com_sex.TabIndex = 104;
            // 
            // com_mahal_tavalod
            // 
            this.com_mahal_tavalod.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.com_mahal_tavalod.FormattingEnabled = true;
            this.com_mahal_tavalod.Items.AddRange(new object[] {
            "آذربایجان شرقی",
            "آذربایجان غربی",
            "اردبیل",
            "اصفهان",
            "البرز",
            "ایلام",
            "بوشهر",
            "تهران",
            "چهارمحال و بختیاری",
            "خراسان جنوبی",
            "خراسان رضوی",
            "خراسان شمالی",
            "خوزستان",
            "زنجان",
            "سمنان",
            "سیستان و بلوچستان",
            "فارس",
            "قزوین",
            "قم",
            "کردستان",
            "کرمان",
            "کرمانشاه",
            "کهگیلویه و بویراحمد",
            "گلستان",
            "گیلان",
            "لرستان",
            "مازندران",
            "مرکزی",
            "هرمزگان",
            "همدان",
            "یزد"});
            this.com_mahal_tavalod.Location = new System.Drawing.Point(680, 155);
            this.com_mahal_tavalod.Name = "com_mahal_tavalod";
            this.com_mahal_tavalod.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.com_mahal_tavalod.Size = new System.Drawing.Size(210, 21);
            this.com_mahal_tavalod.TabIndex = 100;
            // 
            // txt_address
            // 
            this.txt_address.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txt_address.Location = new System.Drawing.Point(7, 255);
            this.txt_address.Multiline = true;
            this.txt_address.Name = "txt_address";
            this.txt_address.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_address.Size = new System.Drawing.Size(422, 46);
            this.txt_address.TabIndex = 114;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(436, 270);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(39, 13);
            this.label13.TabIndex = 133;
            this.label13.Text = ": آدرس";
            // 
            // txt_codeposti
            // 
            this.txt_codeposti.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txt_codeposti.Location = new System.Drawing.Point(219, 230);
            this.txt_codeposti.MaxLength = 10;
            this.txt_codeposti.Name = "txt_codeposti";
            this.txt_codeposti.Size = new System.Drawing.Size(210, 21);
            this.txt_codeposti.TabIndex = 113;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(436, 233);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(58, 13);
            this.label14.TabIndex = 132;
            this.label14.Text = ": کد پستی";
            // 
            // txt_mobile
            // 
            this.txt_mobile.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txt_mobile.Location = new System.Drawing.Point(219, 205);
            this.txt_mobile.Name = "txt_mobile";
            this.txt_mobile.Size = new System.Drawing.Size(210, 21);
            this.txt_mobile.TabIndex = 112;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(436, 208);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(42, 13);
            this.label15.TabIndex = 131;
            this.label15.Text = ": موبایل";
            // 
            // txt_tel
            // 
            this.txt_tel.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txt_tel.Location = new System.Drawing.Point(219, 180);
            this.txt_tel.Name = "txt_tel";
            this.txt_tel.Size = new System.Drawing.Size(210, 21);
            this.txt_tel.TabIndex = 111;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(436, 183);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(64, 13);
            this.label16.TabIndex = 130;
            this.label16.Text = ": تلفن تماس";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(436, 158);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(73, 13);
            this.label17.TabIndex = 129;
            this.label17.Text = ": نوع استخدام";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(436, 133);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(79, 13);
            this.label18.TabIndex = 128;
            this.label18.Text = ": تاریخ استخدام";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(436, 108);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(77, 13);
            this.label19.TabIndex = 127;
            this.label19.Text = ": سمت شغلی";
            // 
            // txt_reshte
            // 
            this.txt_reshte.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txt_reshte.Location = new System.Drawing.Point(219, 80);
            this.txt_reshte.Name = "txt_reshte";
            this.txt_reshte.Size = new System.Drawing.Size(210, 21);
            this.txt_reshte.TabIndex = 107;
            this.txt_reshte.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(436, 83);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(80, 13);
            this.label20.TabIndex = 126;
            this.label20.Text = ": رشته تحصیلی";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(436, 58);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(81, 13);
            this.label21.TabIndex = 125;
            this.label21.Text = ": مدرک تحصیلی";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(896, 283);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(87, 13);
            this.label11.TabIndex = 124;
            this.label11.Text = ": وضعیت سربازی";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(896, 258);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(51, 13);
            this.label10.TabIndex = 123;
            this.label10.Text = ": جنسیت";
            // 
            // txt_shmeli
            // 
            this.txt_shmeli.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txt_shmeli.Location = new System.Drawing.Point(680, 230);
            this.txt_shmeli.MaxLength = 10;
            this.txt_shmeli.Name = "txt_shmeli";
            this.txt_shmeli.Size = new System.Drawing.Size(210, 21);
            this.txt_shmeli.TabIndex = 103;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(896, 233);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(68, 13);
            this.label9.TabIndex = 122;
            this.label9.Text = ": شماره ملّی";
            // 
            // txt_shshenas
            // 
            this.txt_shshenas.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txt_shshenas.Location = new System.Drawing.Point(680, 205);
            this.txt_shshenas.Name = "txt_shshenas";
            this.txt_shshenas.Size = new System.Drawing.Size(210, 21);
            this.txt_shshenas.TabIndex = 102;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(896, 208);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(95, 13);
            this.label8.TabIndex = 121;
            this.label8.Text = ": شماره شناسنامه";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(896, 183);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 13);
            this.label7.TabIndex = 120;
            this.label7.Text = ": تاریخ تولّد";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(896, 158);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 13);
            this.label6.TabIndex = 119;
            this.label6.Text = ": محل تولّد";
            // 
            // txt_pname
            // 
            this.txt_pname.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txt_pname.Location = new System.Drawing.Point(680, 130);
            this.txt_pname.Name = "txt_pname";
            this.txt_pname.Size = new System.Drawing.Size(210, 21);
            this.txt_pname.TabIndex = 99;
            this.txt_pname.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(896, 133);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 13);
            this.label5.TabIndex = 118;
            this.label5.Text = ": نام پدر";
            // 
            // txt_lname
            // 
            this.txt_lname.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txt_lname.Location = new System.Drawing.Point(680, 105);
            this.txt_lname.Name = "txt_lname";
            this.txt_lname.Size = new System.Drawing.Size(210, 21);
            this.txt_lname.TabIndex = 98;
            this.txt_lname.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(896, 108);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 13);
            this.label4.TabIndex = 117;
            this.label4.Text = ": نام خانوادگی";
            // 
            // txt_fname
            // 
            this.txt_fname.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txt_fname.Location = new System.Drawing.Point(680, 80);
            this.txt_fname.Name = "txt_fname";
            this.txt_fname.Size = new System.Drawing.Size(210, 21);
            this.txt_fname.TabIndex = 97;
            this.txt_fname.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(896, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 13);
            this.label3.TabIndex = 116;
            this.label3.Text = ": نام";
            // 
            // txt_shpersonel
            // 
            this.txt_shpersonel.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txt_shpersonel.Location = new System.Drawing.Point(680, 55);
            this.txt_shpersonel.Name = "txt_shpersonel";
            this.txt_shpersonel.Size = new System.Drawing.Size(210, 21);
            this.txt_shpersonel.TabIndex = 96;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(896, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 13);
            this.label2.TabIndex = 115;
            this.label2.Text = ": شناسه فروشنده";
            // 
            // toolStrip1
            // 
            this.toolStrip1.AllowDrop = true;
            this.toolStrip1.AutoSize = false;
            this.toolStrip1.BackColor = System.Drawing.Color.Crimson;
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btn_new,
            this.toolStripSeparator1,
            this.btn_save,
            this.toolStripSeparator2,
            this.btn_edit,
            this.toolStripSeparator3,
            this.btn_delete,
            this.toolStripSeparator4,
            this.btn_refresh,
            this.toolStripSeparator6,
            this.btn_exit});
            this.toolStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.toolStrip1.Location = new System.Drawing.Point(0, 527);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.toolStrip1.Size = new System.Drawing.Size(995, 37);
            this.toolStrip1.TabIndex = 135;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // btn_new
            // 
            this.btn_new.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btn_new.Image = ((System.Drawing.Image)(resources.GetObject("btn_new.Image")));
            this.btn_new.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btn_new.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_new.Name = "btn_new";
            this.btn_new.Size = new System.Drawing.Size(34, 34);
            this.btn_new.Text = "جدید";
            this.btn_new.Click += new System.EventHandler(this.btn_new_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.AutoSize = false;
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(10, 37);
            // 
            // btn_save
            // 
            this.btn_save.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btn_save.Enabled = false;
            this.btn_save.Image = ((System.Drawing.Image)(resources.GetObject("btn_save.Image")));
            this.btn_save.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btn_save.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(34, 34);
            this.btn_save.Text = "ذخیره";
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.AutoSize = false;
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(10, 37);
            // 
            // btn_edit
            // 
            this.btn_edit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btn_edit.Image = ((System.Drawing.Image)(resources.GetObject("btn_edit.Image")));
            this.btn_edit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btn_edit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_edit.Name = "btn_edit";
            this.btn_edit.Size = new System.Drawing.Size(34, 34);
            this.btn_edit.Text = "ویرایش";
            this.btn_edit.Click += new System.EventHandler(this.btn_edit_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.AutoSize = false;
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(10, 37);
            // 
            // btn_delete
            // 
            this.btn_delete.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btn_delete.Image = ((System.Drawing.Image)(resources.GetObject("btn_delete.Image")));
            this.btn_delete.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btn_delete.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(34, 34);
            this.btn_delete.Text = "حذف";
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.AutoSize = false;
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(10, 37);
            // 
            // btn_refresh
            // 
            this.btn_refresh.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btn_refresh.Image = ((System.Drawing.Image)(resources.GetObject("btn_refresh.Image")));
            this.btn_refresh.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btn_refresh.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_refresh.Name = "btn_refresh";
            this.btn_refresh.Size = new System.Drawing.Size(34, 34);
            this.btn_refresh.Text = "بروزرسانی";
            this.btn_refresh.Click += new System.EventHandler(this.btn_refresh_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.AutoSize = false;
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(10, 37);
            // 
            // btn_exit
            // 
            this.btn_exit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btn_exit.Image = ((System.Drawing.Image)(resources.GetObject("btn_exit.Image")));
            this.btn_exit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btn_exit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(34, 34);
            this.btn_exit.Text = "خروج";
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeight = 36;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.shpersonelDataGridViewTextBoxColumn,
            this.fnameDataGridViewTextBoxColumn,
            this.lnameDataGridViewTextBoxColumn,
            this.pnameDataGridViewTextBoxColumn,
            this.mahaltavalodDataGridViewTextBoxColumn,
            this.datetavalodDataGridViewTextBoxColumn,
            this.shshenasDataGridViewTextBoxColumn,
            this.shmeliDataGridViewTextBoxColumn,
            this.sexDataGridViewTextBoxColumn,
            this.sarbaziDataGridViewTextBoxColumn,
            this.madrakDataGridViewTextBoxColumn,
            this.reshteDataGridViewTextBoxColumn,
            this.sematDataGridViewTextBoxColumn,
            this.dateestekhdamDataGridViewTextBoxColumn,
            this.typeestekhdamDataGridViewTextBoxColumn,
            this.telDataGridViewTextBoxColumn,
            this.mobileDataGridViewTextBoxColumn,
            this.codepostiDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.salerBindingSource;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView1.Location = new System.Drawing.Point(7, 325);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.Size = new System.Drawing.Size(981, 177);
            this.dataGridView1.TabIndex = 136;
            this.dataGridView1.Click += new System.EventHandler(this.dataGridView1_Click);
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ردیف";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.ReadOnly = true;
            this.iDDataGridViewTextBoxColumn.Width = 50;
            // 
            // shpersonelDataGridViewTextBoxColumn
            // 
            this.shpersonelDataGridViewTextBoxColumn.DataPropertyName = "shpersonel";
            this.shpersonelDataGridViewTextBoxColumn.HeaderText = "شناسه فروشنده";
            this.shpersonelDataGridViewTextBoxColumn.Name = "shpersonelDataGridViewTextBoxColumn";
            this.shpersonelDataGridViewTextBoxColumn.Width = 80;
            // 
            // fnameDataGridViewTextBoxColumn
            // 
            this.fnameDataGridViewTextBoxColumn.DataPropertyName = "fname";
            this.fnameDataGridViewTextBoxColumn.HeaderText = "نام";
            this.fnameDataGridViewTextBoxColumn.Name = "fnameDataGridViewTextBoxColumn";
            this.fnameDataGridViewTextBoxColumn.Width = 80;
            // 
            // lnameDataGridViewTextBoxColumn
            // 
            this.lnameDataGridViewTextBoxColumn.DataPropertyName = "lname";
            this.lnameDataGridViewTextBoxColumn.HeaderText = "نام خانوادگی";
            this.lnameDataGridViewTextBoxColumn.Name = "lnameDataGridViewTextBoxColumn";
            this.lnameDataGridViewTextBoxColumn.Width = 90;
            // 
            // pnameDataGridViewTextBoxColumn
            // 
            this.pnameDataGridViewTextBoxColumn.DataPropertyName = "pname";
            this.pnameDataGridViewTextBoxColumn.HeaderText = "نام پدر";
            this.pnameDataGridViewTextBoxColumn.Name = "pnameDataGridViewTextBoxColumn";
            this.pnameDataGridViewTextBoxColumn.Width = 80;
            // 
            // mahaltavalodDataGridViewTextBoxColumn
            // 
            this.mahaltavalodDataGridViewTextBoxColumn.DataPropertyName = "mahal_tavalod";
            this.mahaltavalodDataGridViewTextBoxColumn.HeaderText = "محل تولد";
            this.mahaltavalodDataGridViewTextBoxColumn.Name = "mahaltavalodDataGridViewTextBoxColumn";
            // 
            // datetavalodDataGridViewTextBoxColumn
            // 
            this.datetavalodDataGridViewTextBoxColumn.DataPropertyName = "date_tavalod";
            this.datetavalodDataGridViewTextBoxColumn.HeaderText = "تاریخ تولد";
            this.datetavalodDataGridViewTextBoxColumn.Name = "datetavalodDataGridViewTextBoxColumn";
            this.datetavalodDataGridViewTextBoxColumn.Width = 80;
            // 
            // shshenasDataGridViewTextBoxColumn
            // 
            this.shshenasDataGridViewTextBoxColumn.DataPropertyName = "shshenas";
            this.shshenasDataGridViewTextBoxColumn.HeaderText = "شماره شناسنامه";
            this.shshenasDataGridViewTextBoxColumn.Name = "shshenasDataGridViewTextBoxColumn";
            this.shshenasDataGridViewTextBoxColumn.Width = 80;
            // 
            // shmeliDataGridViewTextBoxColumn
            // 
            this.shmeliDataGridViewTextBoxColumn.DataPropertyName = "shmeli";
            this.shmeliDataGridViewTextBoxColumn.HeaderText = "شماره ملی";
            this.shmeliDataGridViewTextBoxColumn.Name = "shmeliDataGridViewTextBoxColumn";
            this.shmeliDataGridViewTextBoxColumn.Width = 90;
            // 
            // sexDataGridViewTextBoxColumn
            // 
            this.sexDataGridViewTextBoxColumn.DataPropertyName = "sex";
            this.sexDataGridViewTextBoxColumn.HeaderText = "جنسیت";
            this.sexDataGridViewTextBoxColumn.Name = "sexDataGridViewTextBoxColumn";
            this.sexDataGridViewTextBoxColumn.Width = 50;
            // 
            // sarbaziDataGridViewTextBoxColumn
            // 
            this.sarbaziDataGridViewTextBoxColumn.DataPropertyName = "sarbazi";
            this.sarbaziDataGridViewTextBoxColumn.HeaderText = "وضعیت سربازی";
            this.sarbaziDataGridViewTextBoxColumn.Name = "sarbaziDataGridViewTextBoxColumn";
            this.sarbaziDataGridViewTextBoxColumn.Width = 90;
            // 
            // madrakDataGridViewTextBoxColumn
            // 
            this.madrakDataGridViewTextBoxColumn.DataPropertyName = "madrak";
            this.madrakDataGridViewTextBoxColumn.HeaderText = "مدرک تحصیلی";
            this.madrakDataGridViewTextBoxColumn.Name = "madrakDataGridViewTextBoxColumn";
            // 
            // reshteDataGridViewTextBoxColumn
            // 
            this.reshteDataGridViewTextBoxColumn.DataPropertyName = "reshte";
            this.reshteDataGridViewTextBoxColumn.HeaderText = "رشته تحصیلی";
            this.reshteDataGridViewTextBoxColumn.Name = "reshteDataGridViewTextBoxColumn";
            // 
            // sematDataGridViewTextBoxColumn
            // 
            this.sematDataGridViewTextBoxColumn.DataPropertyName = "semat";
            this.sematDataGridViewTextBoxColumn.HeaderText = "سمت شغلی";
            this.sematDataGridViewTextBoxColumn.Name = "sematDataGridViewTextBoxColumn";
            // 
            // dateestekhdamDataGridViewTextBoxColumn
            // 
            this.dateestekhdamDataGridViewTextBoxColumn.DataPropertyName = "date_estekhdam";
            this.dateestekhdamDataGridViewTextBoxColumn.HeaderText = "تاریخ استخدام";
            this.dateestekhdamDataGridViewTextBoxColumn.Name = "dateestekhdamDataGridViewTextBoxColumn";
            // 
            // typeestekhdamDataGridViewTextBoxColumn
            // 
            this.typeestekhdamDataGridViewTextBoxColumn.DataPropertyName = "type_estekhdam";
            this.typeestekhdamDataGridViewTextBoxColumn.HeaderText = "نوع استخدام";
            this.typeestekhdamDataGridViewTextBoxColumn.Name = "typeestekhdamDataGridViewTextBoxColumn";
            // 
            // telDataGridViewTextBoxColumn
            // 
            this.telDataGridViewTextBoxColumn.DataPropertyName = "tel";
            this.telDataGridViewTextBoxColumn.HeaderText = "تلفن";
            this.telDataGridViewTextBoxColumn.Name = "telDataGridViewTextBoxColumn";
            // 
            // mobileDataGridViewTextBoxColumn
            // 
            this.mobileDataGridViewTextBoxColumn.DataPropertyName = "mobile";
            this.mobileDataGridViewTextBoxColumn.HeaderText = "موبایل";
            this.mobileDataGridViewTextBoxColumn.Name = "mobileDataGridViewTextBoxColumn";
            // 
            // codepostiDataGridViewTextBoxColumn
            // 
            this.codepostiDataGridViewTextBoxColumn.DataPropertyName = "codeposti";
            this.codepostiDataGridViewTextBoxColumn.HeaderText = "کد پستی";
            this.codepostiDataGridViewTextBoxColumn.Name = "codepostiDataGridViewTextBoxColumn";
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "آدرس";
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            this.addressDataGridViewTextBoxColumn.Width = 200;
            // 
            // salerBindingSource
            // 
            this.salerBindingSource.DataMember = "Saler";
            this.salerBindingSource.DataSource = this.saler_Dataset;
            // 
            // saler_Dataset
            // 
            this.saler_Dataset.DataSetName = "Saler_Dataset";
            this.saler_Dataset.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Book_Shop.Properties.Resources.search;
            this.pictureBox1.Location = new System.Drawing.Point(269, 530);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(28, 25);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 138;
            this.pictureBox1.TabStop = false;
            // 
            // txt_search
            // 
            this.txt_search.BackColor = System.Drawing.Color.White;
            this.txt_search.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txt_search.ForeColor = System.Drawing.Color.Black;
            this.txt_search.Location = new System.Drawing.Point(7, 534);
            this.txt_search.Name = "txt_search";
            this.txt_search.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_search.Size = new System.Drawing.Size(256, 21);
            this.txt_search.TabIndex = 137;
            this.txt_search.TextChanged += new System.EventHandler(this.txt_search_TextChanged);
            // 
            // salerTableAdapter
            // 
            this.salerTableAdapter.ClearBeforeFill = true;
            // 
            // Saler_Frm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Crimson;
            this.ClientSize = new System.Drawing.Size(995, 564);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txt_search);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.txt_date_estekhdam);
            this.Controls.Add(this.txt_date_tavalod);
            this.Controls.Add(this.txt_semat);
            this.Controls.Add(this.com_estekhdam);
            this.Controls.Add(this.com_madarak);
            this.Controls.Add(this.com_sarbazi);
            this.Controls.Add(this.com_sex);
            this.Controls.Add(this.com_mahal_tavalod);
            this.Controls.Add(this.txt_address);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txt_codeposti);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txt_mobile);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txt_tel);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.txt_reshte);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txt_shmeli);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txt_shshenas);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_pname);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_lname);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_fname);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_shpersonel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Saler_Frm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Saler_Frm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.saler_Dataset)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MaskedTextBox txt_date_estekhdam;
        private System.Windows.Forms.MaskedTextBox txt_date_tavalod;
        private System.Windows.Forms.TextBox txt_semat;
        private System.Windows.Forms.ComboBox com_estekhdam;
        private System.Windows.Forms.ComboBox com_madarak;
        private System.Windows.Forms.ComboBox com_sarbazi;
        private System.Windows.Forms.ComboBox com_sex;
        private System.Windows.Forms.ComboBox com_mahal_tavalod;
        private System.Windows.Forms.TextBox txt_address;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txt_codeposti;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txt_mobile;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txt_tel;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txt_reshte;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txt_shmeli;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_shshenas;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_pname;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_lname;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_fname;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_shpersonel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton btn_new;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton btn_save;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton btn_edit;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton btn_delete;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton btn_refresh;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripButton btn_exit;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txt_search;
        private DataSet.Saler_Dataset saler_Dataset;
        private System.Windows.Forms.BindingSource salerBindingSource;
        private DataSet.Saler_DatasetTableAdapters.SalerTableAdapter salerTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn shpersonelDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mahaltavalodDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn datetavalodDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn shshenasDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn shmeliDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sexDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sarbaziDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn madrakDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn reshteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sematDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateestekhdamDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn typeestekhdamDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mobileDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn codepostiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
    }
}