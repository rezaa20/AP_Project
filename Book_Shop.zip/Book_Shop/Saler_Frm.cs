﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Book_Shop
{
    public partial class Saler_Frm : Form
    {
        string id;
        ConnectDb dbs = new ConnectDb();

        public Saler_Frm()
        {
            InitializeComponent();
        }

        public void refresh()
        {

            dbs.connect();
            dataGridView1.DataSource = dbs.select("Select * From Saler");
            dbs.disconnect();

            txt_address.Text = null;
            txt_codeposti.Text = null;
            txt_date_estekhdam.Text = null;
            txt_date_tavalod.Text = null;
            txt_fname.Text = null;
            txt_lname.Text = null;
            txt_mobile.Text = null;
            txt_pname.Text = null;
            txt_reshte.Text = null;
            txt_semat.Text = null;
            txt_shmeli.Text = null;
            txt_shpersonel.Text = null;
            txt_shshenas.Text = null;
            txt_tel.Text = null;
            com_estekhdam.Text = null;
            com_madarak.Text = null;
            com_mahal_tavalod.Text = null;
            com_sarbazi.Text = null;
            com_sex.Text = null;
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
            btn_save.Enabled = false;
            btn_new.Enabled = true;
        }

        private void Saler_Frm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'saler_Dataset.Saler' table. You can move, or remove it, as needed.
            //this.salerTableAdapter.Fill(this.saler_Dataset.Saler);

        }

        private void btn_new_Click(object sender, EventArgs e)
        {
            txt_shpersonel.Focus();
            btn_save.Enabled = true;
            btn_new.Enabled = false;

            refresh();    
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            dbs.connect();
            dbs.docommand("Insert Into Saler(shpersonel,fname,lname,pname,mahal_tavalod,date_tavalod,shshenas,shmeli,sex,sarbazi,madrak,reshte,semat,date_estekhdam,type_estekhdam,tel,mobile,codeposti,address) Values('" + txt_shpersonel.Text + "','" + txt_fname.Text + "','" + txt_lname.Text + "','" + txt_pname.Text + "','" + com_mahal_tavalod.Text + "','" + txt_date_tavalod.Text + "','" + txt_shshenas.Text + "','" + txt_shmeli.Text + "','" + com_sex.Text + "','" + com_sarbazi.Text + "','" + com_madarak.Text + "','" + txt_reshte.Text + "','" + txt_semat.Text + "','" + txt_date_estekhdam.Text + "','" + com_estekhdam.Text + "','" + txt_tel.Text + "','" + txt_mobile.Text + "','" + txt_codeposti.Text + "','" + txt_address.Text + "')");
            dbs.disconnect();
            refresh();
            MessageBox.Show("عملیات ثبت اطلاعات فروشنده با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btn_edit_Click(object sender, EventArgs e)
        {
            dbs.connect();
            dbs.docommand("Update Saler Set shpersonel='" + txt_shpersonel.Text + "',fname='" + txt_fname.Text + "',lname='" + txt_lname.Text + "',pname='" + txt_pname.Text + "',mahal_tavalod='" + com_mahal_tavalod.Text + "',date_tavalod='" + txt_date_tavalod.Text + "',shshenas='" + txt_shshenas.Text + "',shmeli='" + txt_shmeli.Text + "',sex='" + com_sex.Text + "',sarbazi='" + com_sarbazi.Text + "',madrak='" + com_madarak.Text + "',reshte='" + txt_reshte.Text + "',semat='" + txt_semat.Text + "',date_estekhdam='" + txt_date_estekhdam.Text + "',type_estekhdam='" + com_estekhdam.Text + "',tel='" + txt_tel.Text + "',mobile='" + txt_mobile.Text + "',codeposti='" + txt_codeposti.Text + "',address='" + txt_address.Text + "' Where ID='" + id + "'");
            dbs.disconnect();
            refresh();
            MessageBox.Show("عملیات ویرایش اطلاعات فروشنده با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
                        if (MessageBox.Show("آیا مطمئن به حذف فروشنده مورد نظر می باشید", "هشدار", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes) ;
            {
                dbs.connect();
                dbs.docommand("Delete From Saler Where ID='" + id + "'");
                dbs.disconnect();

                refresh();
            }
        }

        private void btn_refresh_Click(object sender, EventArgs e)
        {
            refresh();
            btn_save.Enabled = false;
            btn_new.Enabled = true;
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            id = dataGridView1[0, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_shpersonel.Text = dataGridView1[1, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_fname.Text = dataGridView1[2, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_lname.Text = dataGridView1[3, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_pname.Text = dataGridView1[4, dataGridView1.CurrentRow.Index].Value.ToString();
            com_mahal_tavalod.Text = dataGridView1[5, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_date_tavalod.Text = dataGridView1[6, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_shshenas.Text = dataGridView1[7, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_shmeli.Text = dataGridView1[8, dataGridView1.CurrentRow.Index].Value.ToString();
            com_sex.Text = dataGridView1[9, dataGridView1.CurrentRow.Index].Value.ToString();
            com_sarbazi.Text = dataGridView1[10, dataGridView1.CurrentRow.Index].Value.ToString();
            com_madarak.Text = dataGridView1[11, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_reshte.Text = dataGridView1[12, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_semat.Text = dataGridView1[13, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_date_estekhdam.Text = dataGridView1[14, dataGridView1.CurrentRow.Index].Value.ToString();
            com_estekhdam.Text = dataGridView1[15, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_tel.Text = dataGridView1[16, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_mobile.Text = dataGridView1[17, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_codeposti.Text = dataGridView1[18, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_address.Text = dataGridView1[19, dataGridView1.CurrentRow.Index].Value.ToString();
        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            txt_search.Text = txt_search.Text.Replace("ی", "ي");
            //..جایگزین کردن کاراکتر ي به جای کاراکتر ی 
            txt_search.SelectionStart = txt_search.Text.Length;
            //..رفتن به آخر متن در تکست باکس

            dbs.connect();
            dataGridView1.DataSource = dbs.select("Select * From Saler Where shpersonel='" + txt_search.Text + "' or lname Like N'%" + txt_search.Text + "%'");
            dbs.disconnect();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
