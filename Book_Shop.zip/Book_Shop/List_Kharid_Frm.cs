﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Book_Shop
{
    public partial class List_Kharid_Frm : Form
    {
        ConnectDb dbs = new ConnectDb();
        public string id, id_book, sh_customer;
        public int pricecol, price;

        public List_Kharid_Frm()
        {
            InitializeComponent();
        }

        public void refresh()
        {
            dbs.connect();
            dataGridView1.DataSource = dbs.select("Select Forosh.sh_customer as '" + "شناسه مشتری" + "',Forosh.count as '" + "تعداد کتاب" + "',Forosh.price_col as '" + "قیمت کل" + "',Books.shbook as '" + "شناسه کتاب" + "',Books.name_book as '" + "نام کتاب" + "',Books.subject as '" + "موضوع کتاب" + "',Books.aouther as '" + "نویسنده کتاب" + "',Books.price as '" + "قیمت کتاب" + "' From Forosh Inner Join Books on Forosh.sh_book=Books.shbook Where Forosh.sh_customer='" + sh_customer + "'");
            dbs.disconnect();
        }

        public void sum_price()
        {
            int result = 0;
            foreach (DataGridViewRow row in this.dataGridView1.Rows)
            {
                result += Convert.ToInt32(row.Cells[2].Value);
            }

            lbl_price.Text = result.ToString();
        }
        //...جمع ستون

        private void button1_Click(object sender, EventArgs e)
        {
            Search_Book_Frm sbf = new Search_Book_Frm();
            sbf.ShowDialog();
            id_book = sbf.idbook;
            txt_name_book.Text = sbf.namebook;
            price = sbf.price;
            pricecol = price * Convert.ToInt32(txt_count.Text);
        }

        private void List_Kharid_Frm_Load(object sender, EventArgs e)
        {
            refresh();
            sum_price();
        }

        private void btn_new_Click(object sender, EventArgs e)
        {
            btn_save.Enabled = true;
            btn_new.Enabled = false;

            refresh();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            pricecol = price * Convert.ToInt32(txt_count.Text);
            dbs.connect();
            dbs.docommand("Insert Into Forosh(sh_customer,sh_book,count,price_col) Values('" + sh_customer + "','" + id_book + "','" + txt_count.Text + "','" + pricecol + "')");
            dbs.disconnect();

            MessageBox.Show("عملیات ثبت اطلاعات کتاب با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
            btn_save.Enabled = false;
            btn_new.Enabled = true;
            refresh();
            sum_price();
            lbl_count.Text = dataGridView1.Rows.Count.ToString();
        }

        private void btn_edit_Click(object sender, EventArgs e)
        {
            pricecol = price * Convert.ToInt32(txt_count.Text);
            dbs.connect();
            dbs.docommand("Update Forosh Set sh_customer='" + sh_customer + "',sh_book='" + id_book + "',count='" + txt_count.Text + "',price_col='" + pricecol + "' Where sh_book='" + id_book + "'");
            dbs.disconnect();

            refresh();
            sum_price();
            MessageBox.Show("عملیات ویرایش اطلاعات کتاب با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("آیا مطمئن به حذف کتاب مورد نظر می باشد", "هشدار", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes) ;
            {
                dbs.connect();
                dbs.docommand("Delete From Forosh Where sh_book='" + id_book + "'");
                dbs.disconnect();

                refresh();
            }
            sum_price();
            lbl_count.Text = dataGridView1.Rows.Count.ToString();
        }

        private void btn_refresh_Click(object sender, EventArgs e)
        {
            refresh();
            sum_price();
            btn_save.Enabled = false;
            btn_new.Enabled = true;

            lbl_count.Text = dataGridView1.Rows.Count.ToString();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
            btn_save.Enabled = false;
            btn_new.Enabled = true;
        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            txt_search.Text = txt_search.Text.Replace("ی", "ي");
            txt_search.SelectionStart = txt_search.Text.Length;

            dbs.connect();
            //dataGridView1.DataSource = dbs.select("Select Forosh.sh_customer as '" + "شناسه مشتری" + "',Books.shbook as '" + "شناسه کتاب" + "',Books.name_book as '" + "نام کتاب" + "',Books.subject as '" + "موضوع کتاب" + "',Books.aouther as '" + "نویسنده کتاب" + "',Books.price as '" + "قیمت کتاب" + "' From Forosh Inner Join Books on Forosh.sh_book=Books.shbook Where Forosh.sh_customer='" + sh_customer + "' and Books.name_book Like '%" + txt_search.Text + "%'");
            dataGridView1.DataSource = dbs.select("Select Forosh.sh_customer as '" + "شناسه مشتری" + "',Forosh.count as '" + "تعداد کتاب" + "',Forosh.price_col as '" + "قیمت کل" + "',Books.shbook as '" + "شناسه کتاب" + "',Books.name_book as '" + "نام کتاب" + "',Books.subject as '" + "موضوع کتاب" + "',Books.aouther as '" + "نویسنده کتاب" + "',Books.price as '" + "قیمت کتاب" + "' From Forosh Inner Join Books on Forosh.sh_book=Books.shbook Where Forosh.sh_customer='" + sh_customer + "' and Books.name_book Like '%" + txt_search.Text + "%'");         
            dbs.disconnect();
            sum_price();
            lbl_count.Text = dataGridView1.Rows.Count.ToString();
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            sh_customer = dataGridView1[0, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_count.Text = dataGridView1[1, dataGridView1.CurrentRow.Index].Value.ToString();
            price = Convert.ToInt32(dataGridView1[7, dataGridView1.CurrentRow.Index].Value.ToString());
            id_book = dataGridView1[3, dataGridView1.CurrentRow.Index].Value.ToString();
            txt_name_book.Text = dataGridView1[4, dataGridView1.CurrentRow.Index].Value.ToString();
        }
    }
}
