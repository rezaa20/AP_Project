﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Book_Shop
{
    public partial class Login_Frm : Form
    {
        public string user_type;
        public Login_Frm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Point loc1 = this.PointToScreen(label1.Location);
            loc1 = pictureBox2.PointToClient(loc1);
            label1.Parent = pictureBox2;
            label1.BackColor = Color.Transparent;
            label1.Location = loc1;

            Point loc2 = this.PointToScreen(label2.Location);
            loc2 = pictureBox2.PointToClient(loc2);
            label2.Parent = pictureBox2;
            label2.BackColor = Color.Transparent;
            label2.Location = loc2;

            Point loc3 = this.PointToScreen(label3.Location);
            loc3 = pictureBox2.PointToClient(loc3);
            label3.Parent = pictureBox2;
            label3.BackColor = Color.Transparent;
            label3.Location = loc3;

            Point loc4 = this.PointToScreen(lbl_cancel.Location);
            loc4 = pictureBox1.PointToClient(loc4);
            lbl_cancel.Parent = pictureBox1;
            lbl_cancel.BackColor = Color.Transparent;
            lbl_cancel.Location = loc4;
        }

        ConnectDb dbs = new ConnectDb();
        private void btn_login_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            MainFrm mform = new MainFrm();
            dbs.connect();
            dt = dbs.select("Select * From Login Where username='" + txt_username.Text + "' and password='" + txt_password.Text + "' and usertype='" + user_type + "'");


            if ((txt_username.Text == "") || (txt_password.Text == "") || (com_usertype.Text == ""))
                MessageBox.Show("لطفاً اطلاعات نام کاربری ، رمز عبور و نوع کاربری را وارد کنید", "هشدار", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else
                if (txt_username.Text.Contains("=") || txt_password.Text.Contains("="))
                    MessageBox.Show("استفاده از کاراکترهای غیرمجاز ممنوع می باشد", "هشدار", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                else
                    if (dt.Rows.Count == 0)
                        MessageBox.Show("اطلاعات نام کاربری ، رمز عبور یا نوع کاربری اشتباه می باشد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    else
                    {
                        this.Hide();
                        mform.lbl_user.Text = txt_username.Text;
                        mform.lbl_usertype.Text = com_usertype.Text;
                        mform.Show();
                    }

            dbs.disconnect();
        }

        private void lbl_cancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void com_usertype_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (com_usertype.SelectedIndex == 0)
                user_type = "1";
            else if (com_usertype.SelectedIndex == 1)
                user_type = "0";
        }
    }
}
