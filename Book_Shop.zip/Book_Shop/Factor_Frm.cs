﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Book_Shop
{
    public partial class Factor_Frm : Form
    {
        public string rp,sh_custom;
        Factor_Report r = new Factor_Report();
        public Factor_Frm()
        {
            InitializeComponent();
        }

        private void Factor_Frm_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;

            ConnectDb dbs = new ConnectDb();
            dbs.connect();
            //rp = "Select Personel_Info.sh_personel,Personel_Info.fname,Personel_Info.lname,Personel_Info.shhesab,Account_Salary.salary_khales,Account_Salary.sal,Account_Salary.mah From Personel_Info Inner Join Account_Salary on Personel_Info.sh_personel=Account_Salary.sh_personel Where Personel_Info.sh_workshop='" + code_workshop + "' and Account_Salary.sal='" + year + "' and Account_Salary.mah='" + month + "'";
            //dataGridView1.DataSource = dbs.select("Select Forosh.sh_customer as '" + "شناسه مشتری" + "',Forosh.count as '" + "تعداد کتاب" + "',Forosh.price_col as '" + "قیمت کل" + "',Books.shbook as '" + "شناسه کتاب" + "',Books.name_book as '" + "نام کتاب" + "',Books.subject as '" + "موضوع کتاب" + "',Books.aouther as '" + "نویسنده کتاب" + "',Books.price as '" + "قیمت کتاب" + "',Customer.date_sabt as '" + "تاریخ فروش" + "' From Forosh Inner Join Books on Forosh.sh_book=Books.shbook Inner Join Customer on Customer.sh_customer=Forosh.sh_customer Where Customer.date_sabt='" + date_sabt + "'");            
            //rp = "Select Forosh.sh_customer,Forosh.count,Forosh.price_col,Books.shbook,Books.name_book,Books.price,Customer.date_sabt From Forosh Inner Join Books on Forosh.sh_book=Books.shbook Inner Join Customer on Customer.sh_customer=Forosh.sh_customer Where Forosh.sh_customer='" + "920001" + "'";
            rp = "Select * From View_Factor where sh_customer='" + sh_custom + "' and sh_customer='" + sh_custom + "'";
            r.SetDataSource(dbs.select(rp));
            crystalReportViewer1.ReportSource = r;
            dbs.disconnect();
        }
    }
}
