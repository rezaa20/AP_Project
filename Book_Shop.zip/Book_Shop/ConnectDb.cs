﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Data.SqlClient;
using System.Windows.Forms;

public class ConnectDb
{
    private SqlConnection con;
    private SqlCommand cmd;
    private SqlDataAdapter da;

    public ConnectDb()
    {
        con = new SqlConnection();
        cmd = new SqlCommand();
        da = new SqlDataAdapter();
        cmd.Connection = con;
        da.SelectCommand = cmd;
    }

    public void connect()
    {
        try
        {
            string cs = "Data Source=DESKTOP-DT04CU0\\SAJJAD;Initial Catalog=BookShop;Integrated Security=True";
            con.ConnectionString = cs;
            con.Open();
        }
        catch (System.Data.SqlClient.SqlException)
        {
            MessageBox.Show("را راه اندازی کنید " + "sqlserver " + "سرویس ");
        }
    }

    public void disconnect()
    {
        con.Close();
    }

    public DataTable select(string sql)
    {
        DataTable dt = new DataTable();
        cmd.CommandText = sql;
        da.Fill(dt);
        return dt;
    }


    public void docommand(string sql)
    {
        cmd.CommandText = sql;
        try
        {
            cmd.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            MessageBox.Show(e.ToString());
        }
    }
}
