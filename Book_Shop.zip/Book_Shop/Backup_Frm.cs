﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace Book_Shop
{
    public partial class Backup_Frm : Form
    {
        public Backup_Frm()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folder_open = new FolderBrowserDialog();
            folder_open.ShowDialog();
            txt_patch.Text = folder_open.SelectedPath + @"\BookShop.bak";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (txt_patch.Text == "")
                MessageBox.Show("لطفا مسیر فایل پشتیبان را انتخاب کنید", "اخطار", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {

                File.Delete(txt_patch.Text);
                MessageBox.Show("لطفا در حین عملیات پشتیبان گیری به چیزی دست نزنید", "هشدار", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                string qry1;

                qry1 = "Backup Database BookShop To Disk='" + @txt_patch.Text + "'";
                SqlConnection con = new SqlConnection("Data Source=.;Integrated Security=True");
                con.Open();

                SqlCommand com = new SqlCommand(qry1, con);
                com.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("کاربر گرامی عملیات پشتیبان گیری با موفقیت انجام شد", "پیغام", MessageBoxButtons.OK, MessageBoxIcon.Information);

                
            }
        }

        private void Backup_Frm_Load(object sender, EventArgs e)
        {

        }
    }
}
