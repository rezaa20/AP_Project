﻿namespace Book_Shop
{
    partial class MainFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_anbar = new System.Windows.Forms.Button();
            this.btn_exit = new System.Windows.Forms.Button();
            this.btn_lock = new System.Windows.Forms.Button();
            this.btn_backup = new System.Windows.Forms.Button();
            this.btn_changeuser = new System.Windows.Forms.Button();
            this.btn_newuser = new System.Windows.Forms.Button();
            this.btn_sale = new System.Windows.Forms.Button();
            this.btn_books = new System.Windows.Forms.Button();
            this.btn_seller = new System.Windows.Forms.Button();
            this.btn_customer = new System.Windows.Forms.Button();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.lbl_date = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.lbl_usertype = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel5 = new System.Windows.Forms.ToolStripStatusLabel();
            this.lbl_user = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel7 = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.lbl_date,
            this.toolStripStatusLabel3,
            this.lbl_usertype,
            this.toolStripStatusLabel5,
            this.lbl_user,
            this.toolStripStatusLabel7});
            this.statusStrip1.Location = new System.Drawing.Point(0, 717);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1062, 22);
            this.statusStrip1.TabIndex = 7;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.btn_anbar);
            this.panel1.Controls.Add(this.btn_exit);
            this.panel1.Controls.Add(this.btn_lock);
            this.panel1.Controls.Add(this.btn_backup);
            this.panel1.Controls.Add(this.btn_changeuser);
            this.panel1.Controls.Add(this.btn_newuser);
            this.panel1.Controls.Add(this.btn_sale);
            this.panel1.Controls.Add(this.btn_books);
            this.panel1.Controls.Add(this.btn_seller);
            this.panel1.Controls.Add(this.btn_customer);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(841, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(221, 717);
            this.panel1.TabIndex = 8;
            // 
            // btn_anbar
            // 
            this.btn_anbar.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btn_anbar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_anbar.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_anbar.ForeColor = System.Drawing.Color.White;
            this.btn_anbar.Image = global::Book_Shop.Properties.Resources.anbar;
            this.btn_anbar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_anbar.Location = new System.Drawing.Point(4, 210);
            this.btn_anbar.Name = "btn_anbar";
            this.btn_anbar.Size = new System.Drawing.Size(213, 62);
            this.btn_anbar.TabIndex = 14;
            this.btn_anbar.Text = "فرم انبار فروشگاه";
            this.btn_anbar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_anbar.UseVisualStyleBackColor = false;
            this.btn_anbar.Click += new System.EventHandler(this.btn_anbar_Click);
            this.btn_anbar.MouseLeave += new System.EventHandler(this.btn_anbar_MouseLeave);
            this.btn_anbar.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btn_anbar_MouseMove);
            // 
            // btn_exit
            // 
            this.btn_exit.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btn_exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_exit.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_exit.ForeColor = System.Drawing.Color.White;
            this.btn_exit.Image = global::Book_Shop.Properties.Resources.exit;
            this.btn_exit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_exit.Location = new System.Drawing.Point(4, 618);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(213, 62);
            this.btn_exit.TabIndex = 13;
            this.btn_exit.Text = "خروج از سیستم";
            this.btn_exit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_exit.UseVisualStyleBackColor = false;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            this.btn_exit.MouseLeave += new System.EventHandler(this.btn_exit_MouseLeave);
            this.btn_exit.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btn_exit_MouseMove);
            // 
            // btn_lock
            // 
            this.btn_lock.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btn_lock.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_lock.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_lock.ForeColor = System.Drawing.Color.White;
            this.btn_lock.Image = global::Book_Shop.Properties.Resources.locking;
            this.btn_lock.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_lock.Location = new System.Drawing.Point(4, 550);
            this.btn_lock.Name = "btn_lock";
            this.btn_lock.Size = new System.Drawing.Size(213, 62);
            this.btn_lock.TabIndex = 12;
            this.btn_lock.Text = "قفل کردن نرم افزار";
            this.btn_lock.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_lock.UseVisualStyleBackColor = false;
            this.btn_lock.Click += new System.EventHandler(this.btn_lock_Click);
            this.btn_lock.MouseLeave += new System.EventHandler(this.btn_lock_MouseLeave);
            this.btn_lock.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btn_lock_MouseMove);
            // 
            // btn_backup
            // 
            this.btn_backup.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btn_backup.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_backup.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_backup.ForeColor = System.Drawing.Color.White;
            this.btn_backup.Image = global::Book_Shop.Properties.Resources.backup;
            this.btn_backup.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_backup.Location = new System.Drawing.Point(4, 482);
            this.btn_backup.Name = "btn_backup";
            this.btn_backup.Size = new System.Drawing.Size(213, 62);
            this.btn_backup.TabIndex = 11;
            this.btn_backup.Text = "فرم تهیه نسخه پشتیبان";
            this.btn_backup.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_backup.UseVisualStyleBackColor = false;
            this.btn_backup.Click += new System.EventHandler(this.btn_backup_Click);
            this.btn_backup.MouseLeave += new System.EventHandler(this.btn_backup_MouseLeave);
            this.btn_backup.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btn_backup_MouseMove);
            // 
            // btn_changeuser
            // 
            this.btn_changeuser.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btn_changeuser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_changeuser.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_changeuser.ForeColor = System.Drawing.Color.White;
            this.btn_changeuser.Image = global::Book_Shop.Properties.Resources.change_user;
            this.btn_changeuser.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_changeuser.Location = new System.Drawing.Point(4, 414);
            this.btn_changeuser.Name = "btn_changeuser";
            this.btn_changeuser.Size = new System.Drawing.Size(213, 62);
            this.btn_changeuser.TabIndex = 10;
            this.btn_changeuser.Text = "فرم تغییر نام کاربری";
            this.btn_changeuser.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_changeuser.UseVisualStyleBackColor = false;
            this.btn_changeuser.Click += new System.EventHandler(this.btn_changeuser_Click);
            this.btn_changeuser.MouseLeave += new System.EventHandler(this.btn_changeuser_MouseLeave);
            this.btn_changeuser.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btn_changeuser_MouseMove);
            // 
            // btn_newuser
            // 
            this.btn_newuser.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btn_newuser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_newuser.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_newuser.ForeColor = System.Drawing.Color.White;
            this.btn_newuser.Image = global::Book_Shop.Properties.Resources.new_user;
            this.btn_newuser.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_newuser.Location = new System.Drawing.Point(4, 346);
            this.btn_newuser.Name = "btn_newuser";
            this.btn_newuser.Size = new System.Drawing.Size(213, 62);
            this.btn_newuser.TabIndex = 9;
            this.btn_newuser.Text = "فرم ایجاد کاربر جدید";
            this.btn_newuser.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_newuser.UseVisualStyleBackColor = false;
            this.btn_newuser.Click += new System.EventHandler(this.btn_newuser_Click);
            this.btn_newuser.MouseLeave += new System.EventHandler(this.btn_newuser_MouseLeave);
            this.btn_newuser.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btn_newuser_MouseMove);
            // 
            // btn_sale
            // 
            this.btn_sale.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btn_sale.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_sale.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_sale.ForeColor = System.Drawing.Color.White;
            this.btn_sale.Image = global::Book_Shop.Properties.Resources.sale;
            this.btn_sale.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_sale.Location = new System.Drawing.Point(4, 278);
            this.btn_sale.Name = "btn_sale";
            this.btn_sale.Size = new System.Drawing.Size(213, 62);
            this.btn_sale.TabIndex = 8;
            this.btn_sale.Text = "لیست فروش";
            this.btn_sale.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_sale.UseVisualStyleBackColor = false;
            this.btn_sale.Click += new System.EventHandler(this.btn_sale_Click);
            this.btn_sale.MouseLeave += new System.EventHandler(this.btn_sale_MouseLeave);
            this.btn_sale.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btn_sale_MouseMove);
            // 
            // btn_books
            // 
            this.btn_books.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btn_books.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_books.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_books.ForeColor = System.Drawing.Color.White;
            this.btn_books.Image = global::Book_Shop.Properties.Resources.book;
            this.btn_books.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_books.Location = new System.Drawing.Point(4, 142);
            this.btn_books.Name = "btn_books";
            this.btn_books.Size = new System.Drawing.Size(213, 62);
            this.btn_books.TabIndex = 7;
            this.btn_books.Text = "فرم اطلاعات کتاب";
            this.btn_books.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_books.UseVisualStyleBackColor = false;
            this.btn_books.Click += new System.EventHandler(this.btn_books_Click);
            this.btn_books.MouseLeave += new System.EventHandler(this.btn_books_MouseLeave);
            this.btn_books.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btn_books_MouseMove);
            // 
            // btn_seller
            // 
            this.btn_seller.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btn_seller.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_seller.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_seller.ForeColor = System.Drawing.Color.White;
            this.btn_seller.Image = global::Book_Shop.Properties.Resources.saler;
            this.btn_seller.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_seller.Location = new System.Drawing.Point(4, 74);
            this.btn_seller.Name = "btn_seller";
            this.btn_seller.Size = new System.Drawing.Size(213, 62);
            this.btn_seller.TabIndex = 6;
            this.btn_seller.Text = "فرم اطلاعات فروشنده";
            this.btn_seller.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_seller.UseVisualStyleBackColor = false;
            this.btn_seller.Click += new System.EventHandler(this.btn_seller_Click);
            this.btn_seller.MouseLeave += new System.EventHandler(this.btn_seller_MouseLeave);
            this.btn_seller.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btn_seller_MouseMove);
            // 
            // btn_customer
            // 
            this.btn_customer.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btn_customer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_customer.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_customer.ForeColor = System.Drawing.Color.White;
            this.btn_customer.Image = global::Book_Shop.Properties.Resources.customer;
            this.btn_customer.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_customer.Location = new System.Drawing.Point(4, 6);
            this.btn_customer.Name = "btn_customer";
            this.btn_customer.Size = new System.Drawing.Size(213, 62);
            this.btn_customer.TabIndex = 5;
            this.btn_customer.Text = "فرم اطلاعات مشتری";
            this.btn_customer.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_customer.UseVisualStyleBackColor = false;
            this.btn_customer.Click += new System.EventHandler(this.btn_customer_Click);
            this.btn_customer.MouseLeave += new System.EventHandler(this.btn_customer_MouseLeave);
            this.btn_customer.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btn_customer_MouseMove);
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.BackColor = System.Drawing.SystemColors.Control;
            this.toolStripStatusLabel1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(16, 17);
            this.toolStripStatusLabel1.Text = "   ";
            // 
            // lbl_date
            // 
            this.lbl_date.BackColor = System.Drawing.SystemColors.Control;
            this.lbl_date.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_date.Name = "lbl_date";
            this.lbl_date.Size = new System.Drawing.Size(491, 17);
            this.lbl_date.Text = "................................................................................." +
                "........................................";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.BackColor = System.Drawing.SystemColors.Control;
            this.toolStripStatusLabel3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(43, 17);
            this.toolStripStatusLabel3.Text = "            ";
            // 
            // lbl_usertype
            // 
            this.lbl_usertype.BackColor = System.Drawing.SystemColors.Control;
            this.lbl_usertype.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_usertype.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbl_usertype.Name = "lbl_usertype";
            this.lbl_usertype.Size = new System.Drawing.Size(39, 17);
            this.lbl_usertype.Text = "........";
            // 
            // toolStripStatusLabel5
            // 
            this.toolStripStatusLabel5.BackColor = System.Drawing.SystemColors.Control;
            this.toolStripStatusLabel5.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.toolStripStatusLabel5.Name = "toolStripStatusLabel5";
            this.toolStripStatusLabel5.Size = new System.Drawing.Size(17, 17);
            this.toolStripStatusLabel5.Text = " / ";
            // 
            // lbl_user
            // 
            this.lbl_user.BackColor = System.Drawing.SystemColors.Control;
            this.lbl_user.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_user.ForeColor = System.Drawing.Color.Blue;
            this.lbl_user.LinkColor = System.Drawing.Color.Blue;
            this.lbl_user.Name = "lbl_user";
            this.lbl_user.Size = new System.Drawing.Size(39, 17);
            this.lbl_user.Text = "........";
            // 
            // toolStripStatusLabel7
            // 
            this.toolStripStatusLabel7.BackColor = System.Drawing.SystemColors.Control;
            this.toolStripStatusLabel7.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel7.Name = "toolStripStatusLabel7";
            this.toolStripStatusLabel7.Size = new System.Drawing.Size(108, 17);
            this.toolStripStatusLabel7.Text = ": نام کاربر / نوع کاربری";
            // 
            // MainFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.BackgroundImage = global::Book_Shop.Properties.Resources.back_book;
            this.ClientSize = new System.Drawing.Size(1062, 739);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip1);
            this.IsMdiContainer = true;
            this.Name = "MainFrm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "E-Book نرم افزار کتاب فروشی";
            this.Load += new System.EventHandler(this.ManiFrm_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_exit;
        private System.Windows.Forms.Button btn_lock;
        private System.Windows.Forms.Button btn_backup;
        private System.Windows.Forms.Button btn_changeuser;
        private System.Windows.Forms.Button btn_newuser;
        private System.Windows.Forms.Button btn_sale;
        private System.Windows.Forms.Button btn_books;
        private System.Windows.Forms.Button btn_seller;
        private System.Windows.Forms.Button btn_customer;
        private System.Windows.Forms.Button btn_anbar;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel lbl_date;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel5;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel7;
        public System.Windows.Forms.ToolStripStatusLabel lbl_usertype;
        public System.Windows.Forms.ToolStripStatusLabel lbl_user;

    }
}